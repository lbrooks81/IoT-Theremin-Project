.. include:: ../README.rst

----

.. toctree::

   installation
   usage
   examples
   CONTRIBUTING
   api/index
   version-history

.. only:: html

   :ref:`genindex`
