Module-wide Default Settings
============================

.. currentmodule:: sounddevice

.. autoclass:: default
   :members:
