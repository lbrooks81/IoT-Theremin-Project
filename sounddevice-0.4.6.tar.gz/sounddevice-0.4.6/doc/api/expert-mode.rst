Expert Mode
===========

.. currentmodule:: sounddevice

.. topic:: Overview

   .. autosummary::
      :nosignatures:
   
      _initialize
      _terminate
      _split
      _StreamBase

.. autofunction:: _initialize

.. autofunction:: _terminate

.. autofunction:: _split

.. autoclass:: _StreamBase
