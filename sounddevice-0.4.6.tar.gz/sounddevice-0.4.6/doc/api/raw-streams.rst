Raw Streams
===========

.. currentmodule:: sounddevice

.. topic:: Overview

   .. autosummary::
      :nosignatures:
   
      RawStream
      RawInputStream
      RawOutputStream

.. autoclass:: RawStream
   :members: read, write

.. autoclass:: RawInputStream

.. autoclass:: RawOutputStream
