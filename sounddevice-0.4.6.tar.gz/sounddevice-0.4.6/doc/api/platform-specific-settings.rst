Platform-specific Settings
==========================

.. currentmodule:: sounddevice

.. topic:: Overview

   .. autosummary::
      :nosignatures:
   
      AsioSettings
      CoreAudioSettings
      WasapiSettings

.. autoclass:: AsioSettings

.. autoclass:: CoreAudioSettings

.. autoclass:: WasapiSettings
