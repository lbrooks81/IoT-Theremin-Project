API Documentation
=================

.. automodule:: sounddevice

----

.. toctree::

   convenience-functions
   checking-hardware
   module-defaults
   platform-specific-settings
   streams
   raw-streams
   misc
   expert-mode
